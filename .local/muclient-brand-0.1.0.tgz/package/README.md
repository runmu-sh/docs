# @muclient/brand

The runmu.sh look, for every site that wears it: the runmu.sh sites in `clients/site` (front page, `/login/`, `/games/`, `/marketplace/`) and the documentation at `/docs/`, which lives in its own public repository ([runmu-sh/docs](https://github.com/runmu-sh/docs)) and can only share the shell through a published package. This is that package.

| Export | Holds |
|---|---|
| `styles/tokens.css` | Every colour, the two font stacks and `--gutter`. **The one place a colour literal may appear**; `clients/site/scripts/check.mjs` fails a literal anywhere else, and the docs repo's check does the same. Dark only. |
| `styles/shell.css` | What `SiteShell` renders needs: `.wrap`, `.skip`, the header (`.nav`, `.brand`, `.nav-links`, `#account-slot`), the footer (`.foot`), the `.btn` family and the responsive gutter. No resets, no `body` rule: the page brings its own (`@muclient/site-ui/styles/base.css` on runmu.sh, the theme on `/docs/`). |
| `SiteShell` (Vue) | The header with the nav and the `account` slot, the page (`default` slot) and the footer. Props: `section` (`home \| games \| marketplace \| docs \| login`, sets `aria-current`), `playBase` (the web client's origin, default `https://play.runmu.sh`), `siteBase` (the runmu.sh origin the nav links point at; `''` on runmu.sh itself). |
| `FONTS_HREF`, `fonts.json` | The Google Fonts stylesheet URL (Source Sans 3, IBM Plex Mono), the sites' one third party; the JSON form is for a Node-side config (VitePress's) that cannot import TypeScript. |

The header and footer in `clients/site/index.html` (static HTML) must equal what `SiteShell` renders; `clients/site/src/shell-parity.test.ts` proves it and `check.mjs` runs it. A change to the nav is a change to both, in one commit.

## Rules
- Imports nothing but Vue (`check.mjs` enforces it): no API, no session, no router, no site-ui. It is published on its own and consumed by a repository that has none of those.
- Selectors are a contract: the e2e suites (`games-e2e.mjs`, `market-e2e.mjs`) locate by `.account-menu summary`, `a.btn-primary` and friends.
- Source is published as-is (`.vue` + `.ts`, `files: ["src"]`): every consumer is a Vite + Vue app that compiles SFCs, so there is no build step to keep in sync.

## Publishing
`npm version <patch|minor|major> -w @muclient/brand` in `clients/`, commit, then `.github/workflows/publish-brand.yml` (run by hand) publishes to npmjs under the public `@muclient` scope. The docs repo pins the version and Dependabot proposes the bump.
