<script lang="ts">
export type Section = 'home' | 'games' | 'marketplace' | 'docs' | 'login';
</script>

<script setup lang="ts">
// The site shell on every page of runmu.sh (R-LAND-SHELL): the header with the nav and the account
// slot, the page's <main> (the slot) and the footer. The markup is the one clients/landing/partials/
// had; the static front page keeps its own copy inline and scripts/check.mjs compares the two, and
// the docs site (runmu-sh/docs, served at /docs/) renders this same component from @muclient/brand.
//
// `playBase` is this deployment's web client (a <meta name="play-url"> or a local run): every
// `data-play-href` link is resolved against it, as shell.js did. `siteBase` is the runmu.sh origin
// the nav links point at: '' (same origin) on runmu.sh itself, an absolute origin when the shell is
// rendered from another host (a docs dev server).
import { computed } from 'vue';

const props = withDefaults(defineProps<{
  /** Which nav link is current (`aria-current`). */
  section: Section;
  /** The web client's origin, no trailing slash. */
  playBase?: string;
  /** The runmu.sh origin the Games / Extensions / Docs / Log in links point at, no trailing slash. */
  siteBase?: string;
}>(), { playBase: 'https://play.runmu.sh', siteBase: '' });

const play = (path: string) => `${props.playBase}${path}`;
const site = (path: string) => `${props.siteBase}${path}`;
const current = (nav: Section) => (props.section === nav ? 'page' : undefined);
const links = computed(() => [
  { href: site('/games/'), nav: 'games' as const, label: 'Games' },
  { href: site('/marketplace/'), nav: 'marketplace' as const, label: 'Extensions' },
  { href: site('/docs/'), nav: 'docs' as const, label: 'Docs' },
]);
</script>

<template>
  <header class="nav">
    <div class="wrap">
      <a class="brand" :href="site('/')"><span>μ</span>Client</a>
      <nav class="nav-links" aria-label="Main">
        <a v-for="l in links" :key="l.nav" :href="l.href" :data-nav="l.nav" :aria-current="current(l.nav)">{{ l.label }}</a>
        <span id="account-slot" class="keep"><slot name="account"><a class="keep" :href="site('/login/')">Log in</a></slot></span>
        <a class="btn btn-primary btn-sm" :href="play('/')" data-play-href="/">Play now</a>
      </nav>
    </div>
  </header>
  <slot />
  <footer class="foot">
    <div class="wrap">
      <span>runmu.sh</span>
      <nav aria-label="Footer">
        <a :href="site('/')">Home</a>
        <a :href="play('/')" data-play-href="/">Play</a>
        <a :href="site('/games/')">Games</a>
        <a :href="site('/marketplace/')">Extensions</a>
        <a :href="site('/docs/')">Docs</a>
        <a href="https://github.com/runmu-sh/releases/releases/latest">Downloads</a>
      </nav>
    </div>
  </footer>
</template>
