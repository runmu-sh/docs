// @muclient/brand: the runmu.sh look every site that wears it shares (the runmu.sh sites in
// clients/site, the docs at /docs/ from runmu-sh/docs). Tokens and the shell's CSS are the package's
// `styles/tokens.css` and `styles/shell.css`. Imports nothing but Vue.
export { default as SiteShell, type Section } from './SiteShell.vue';

import fonts from './fonts.json';

/** The one third party: the fonts. A page puts this in a `<link rel="stylesheet">`; the CSP allows fonts.googleapis.com and fonts.gstatic.com. Plain JSON at `@muclient/brand/fonts.json` too, for a Node-side config that cannot import TypeScript. */
export const FONTS_HREF: string = fonts.href;
